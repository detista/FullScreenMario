FullScreenMario.FullScreenMario.settings.events = {
    "keyOnClassCycleStart": "onThingAdd",
    "keyDoClassCycleStart": "placed",
    "keyCycleCheckValidity": "alive",
    "timingDefault": 9
};
