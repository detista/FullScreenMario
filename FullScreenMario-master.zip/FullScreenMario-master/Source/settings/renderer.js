FullScreenMario.FullScreenMario.settings.renderer = {
    "groupNames": ["Text", "Character", "Solid", "Scenery"],
    "spriteCacheCutoff": 2048
};
